myfile=fopen('element_including_vitreous.txt','w');
n=8; %%% Number of element between each two boundary
row=4; %% Number of boundary in each slide
NS=13; %%% Number of all slides for providing node


 fprintf(myfile,' MISS Version 1.21 ipelem File Version 2 \n Heading: \n \n The number of elements is [1]: %2d ',(n*(row-1))*(NS-1));
for j=1:NS-1
    for r=1:(row-1) 
            for i=1:n
                fprintf(myfile,'\n \n Element number [    %2d]: %2d',i+(r-1)*8+(j-1)*24,i+(r-1)*8+(j-1)*24);
                fprintf(myfile,'\n The number of geometric Xj-coordinates is [2]: 3 \n The basis function type for geometric variable 1 is [1]: 1 \n The basis function type for geometric variable 2 is [1]: 1 \n The basis function type for geometric variable 3 is [1]: 1');
                fprintf(myfile,'\n Enter the 8 global numbers for basis 1: %2d %2d %2d %2d %2d %2d %2d %2d',1+(i-1)+(r-1)*9+(j-1)*36,2+(i-1)+(r-1)*9+(j-1)*36,37+(i-1)+(r-1)*9+(j-1)*36,38+(i-1)+(r-1)*9+(j-1)*36,10+(i-1)+(r-1)*9+(j-1)*36,11+(i-1)+(r-1)*9+(j-1)*36,46+(i-1)+(r-1)*9+(j-1)*36,47+(i-1)+(r-1)*9+(j-1)*36);
            end
    end
end


%%% 9 is because of number of nodes in eaxh boudary
%%% 36 is because of number of elements between each two slides
