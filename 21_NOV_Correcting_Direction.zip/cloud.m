close all;
clear all

I=imread('croped1.jpg');

Ad=I(150:400,:,1);


Ad=imadjust(Ad,stretchlim(Ad));
A_edge=edge(Ad,'canny',[0.1,0.5]);
dim=size(Ad);
% %%% Vertical Clearing %%%%%%%%%%%%%%%%%%%%%%%%%%
w=3;
Binary_vertical_cleared=A_edge;

for j=1:dim(2)
    for i=1:dim(1)
        imax=min(w+i,dim(1));
        if Binary_vertical_cleared(i:imax,j)==1
        Binary_vertical_cleared(i:imax,j)=0;
        end
    end
end

% %%%%% Finding Vitreous Boundary Pixels %%%%%%%%

V_pixel=zeros(dim);

for i=dim(1):-1:1
    for j=1:dim(2)
        if (Binary_vertical_cleared(i,j)==1)
            if (V_pixel(i+1:dim(1),j)==0)
            V_pixel(i,j)=1;
            
            end
        end
    end
end
 V_pixel=bwareaopen(V_pixel,10);

% % % % %%%%%%%%%%%% Vitreous Linking
for i=1:dim(1)
    for j=1:dim(2)
        imin=max(1,i-3);
        imax=min(i+3,dim(1));
        jmin=min(j+1,dim(2));
        jmax=min(j+2,dim(2));
        if V_pixel(i,j)==1
            if(V_pixel(imin:imax,jmin:jmax)==0)
                [r4,c4]=find(V_pixel(1:dim(1),jmin:dim(2)));
                if ~(isempty(c4))
                    dimr=size(r4);
                    dis=zeros(dimr(1),1);
                    for s=1:dimr(1)
                        dis(s)=abs(i-r4(s))+c4(s);
                    end
                    indexmin=find(min(dis)==dis,1);
                    if abs(i-r4(indexmin))<30
                        jindex=min(dim(2),jmin+c4(indexmin));
                        rpts = linspace(i,r4(indexmin));
                        cpts = linspace(jmin,jindex);
                        index = sub2ind(dim,round(rpts),round(cpts));
                        V_pixel(index)=255;
                    end
                end
            end
        end
    end
end
V_pixel=imdilate(V_pixel,strel('disk',3));
V_pixel=bwmorph(V_pixel,'thin',inf);
V_pixel=bwareaopen(V_pixel,50);
% Vitreous=V_pixel;


%% Data Claud provider Writing Only Viterous/Retina
Shorten_Vitreous=zeros(size(V_pixel));
dim=size(V_pixel);
for i=1:dim(1)
    for j=1:20:dim(2)
        
            Shorten_Vitreous(i,j)=V_pixel(i,j);
        
    end
end
%figure,imshow(Shorten_Vitreous);
[r,c]=find(Shorten_Vitreous);
Vitr=[r,c];
% 
%% 
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Finding RPE+IS+OS/ONL %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
A_edge=edge(Ad, 'canny', [0.2,0.6]);
%%%%%%% Vertical Clearing %%%%%%%%%%%%%%%%%%%%%%%%
w=3;
A_vertical_cleared=A_edge;

for j=1:dim(2)
    for i=1:dim(1)
        imax=min(w+i,dim(1));
        if A_vertical_cleared(i:imax,j)==1
        A_vertical_cleared(i:imax,j)=0;
        end
    end
end
A=bwmorph(A_vertical_cleared,'bridge',inf);
A=bwareaopen(A,20);

%%%%%%% pixel 

ISOS_pixel=zeros(dim);

for i=1:dim(1)
    imin=max(i-1, 1);
    for j=1:dim(2)
        if (V_pixel(i,j)==1)
            for in=imin:-1:1
                if (A(in,j)==1)
                    if   in<i-35
                        if (ISOS_pixel(in+1:dim(1),j)==0)
                            ISOS_pixel(in,j)=1;
                        end
                    end
                end
            end
        end
    end
end
 ISOS_pixel=bwareaopen(ISOS_pixel,15);
% % % %%%%% Second layer Linking
 for i=1:dim(1)
     for j=1:dim(2)
         imin=max(1,i-1);
         imax=min(i+1,dim(1));
         jmin=min(j+1,dim(2));
         jmax=min(j+2,dim(2));
         if ISOS_pixel(i,j)==1
             if(ISOS_pixel(imin:imax,jmin:jmax)==0)
                 [r4,c4]=find(ISOS_pixel(1:dim(1),jmin:dim(2)));
                 if ~(isempty(c4))
                     dimr=size(r4);
                     dis=zeros(dimr(1),1);
                     for s=1:dimr(1)
                         dis(s)=abs(i-r4(s))+c4(s);
                     end
                     indexmin=find(min(dis)==dis,1);
                     if abs(i-r4(indexmin))<10
                         jindex=min(dim(2),jmin+c4(indexmin));
                         rpts = linspace(i,r4(indexmin));
                         cpts = linspace(jmin,jindex);
                         index = sub2ind(dim,round(rpts),round(cpts));
                         ISOS_pixel(index)=255;
                     end
                 end
             end
         end
     end
 end
% ISOS_pixel=bwareaopen(ISOS_pixel,20);

% RPEISOS=ISOS_pixel;
%% Data Claud provider from RPE+ISOS/ONL boundary
ISOS(:,:)=ISOS_pixel;
dim=size(ISOS);
shorten_ISOS=zeros(dim);
for i=1:dim(1)
    for j=1:25:dim(2)
        
            shorten_ISOS(i,j)=ISOS_pixel(i,j);
        
    end
end
% figure,imshow(A(:,:));
Shorten_ISOS(:,:,1)=shorten_ISOS(:,:,1);
 %figure,imshow(Shorten_ISOS(:,:,1));
 
[r,c]=find(Shorten_ISOS);
ISOS=[r,c];
%%
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Finding Chroid/RPE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% % %%%%%%%% Pre Processing %%%%%%%%%%%%
M=medfilt2(Ad,[5,10]);
A_edge=edge(M,'canny',[0.2,0.3]);
dim=size(A_edge);
%%%%%%% Finding First Layer Pixel%%%%%%%%%%%%%%%%%
RPE_pixel=zeros(dim);

 for i=1:dim(1)
     for j=1:dim(2)
         if (ISOS_pixel(i,j)==1)
            for in=i-2:-1:1
                if A_edge(in,j)==1
                    if  in>i-23 && in<i-13
                        if (RPE_pixel(in:dim(1),j)==0)
                            RPE_pixel(in,j)=1;
                        end
                    end
                end
            end
         end
     end
 end
% RPE_pixel=bwareaopen(RPE_pixel,10);
% % %%%%% First layer Linking
for i=1:dim(1)
    for j=1:dim(2)
        imin=max(1,i-1);
        imax=min(i+1,dim(1));
        jmin=min(j+1,dim(2));
        jmax=min(j+2,dim(2));
        if RPE_pixel(i,j)==1
            if(RPE_pixel(imin:imax,jmin:jmax)==0)
                [r4,c4]=find(RPE_pixel(1:dim(1),jmin:dim(2)));
                if ~(isempty(c4))
                    dimr=size(r4);
                    dis=zeros(dimr(1),1);
                    for s=1:dimr(1)
                        dis(s)=abs(i-r4(s))+c4(s);
                    end
                    indexmin=find(min(dis)==dis,1);
                    jindex=min(dim(2),jmin+c4(indexmin));
                    rpts = linspace(i,r4(indexmin));
                    cpts = linspace(jmin,jindex);
                    index = sub2ind(dim,round(rpts),round(cpts));
                    RPE_pixel(index)=255;
                end
            end
        end
    end
end
% figure,imshow(RPE_pixel);
% ChroidRPE=RPE_pixel;

%% Data Claud provider from Choroid/RPE boundary
RPE(:,:)=RPE_pixel;
dim=size(RPE);
shorten_RPE=zeros(dim);
for i=1:dim(1)
    for j=1:25:dim(2)
        
            shorten_RPE(i,j)=RPE_pixel(i,j);
        
    end
end
% figure,imshow(A(:,:));
Shorten_RPE(:,:,1)=shorten_RPE(:,:,1);
% figure,imshow(Shorten_RPE(:,:,1));
[r,c]=find(Shorten_RPE);
RPE=[r,c];
%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% IPL+GCL/NFL Boundary %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % %%%%%%% Pre Processing
I=I(:,:,1);
image=I(150:400,:,1);
Nfilter=4;
[Denoisedimage,im_enhanced]=DenoisingFunction( image,Nfilter );
% figure,imshow(Denoisedimage),title('denoised  by 4');
% figure,imshow(im_enhanced),title('enhanced by 4');

im_enhanced=medfilt2(im_enhanced,[3,10]);
im_enhanced=imadjust(im_enhanced,stretchlim(im_enhanced)); 
edge_enhanced=edge(im_enhanced,'canny',[0.2,0.3]);

% %%%%%%%%% Filtering By vitreous and Second Layer
 dim=size(image);
for i=1:dim(1)
    for j=1:dim(2)
         if V_pixel(i,j)==1
            imin=min(dim(1),i+10);
            edge_enhanced(imin:dim(1),j)=0;
         end
         imax=min(i-50,1);
         if ISOS_pixel(i,j)==1
             edge_enhanced(1:imax)=0;
         end
       
    end
    
end
 
%%% Vertical Clearing %%%%%%%%%%%%%%%%%%%%%%%%%%
w=3;
edge_enhanced_vertical_cleared=edge_enhanced;

for j=1:dim(2)
    for i=1:dim(1)
        imax=min(w+i,dim(1));
        if edge_enhanced_vertical_cleared(i:imax,j)==1
        edge_enhanced_vertical_cleared(i:imax,j)=0;
        end
    end
end

% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Finidng NFC_pixel %%%%%%%%%%%%

NFC_pixel=zeros(dim);

for i=dim(1):-1:1
    for j=1:dim(2)
        if V_pixel(i,j)==1
            for in=i-4:-1:1
                if edge_enhanced(in,j)==1
                    if in<imin 
                        if NFC_pixel(in:dim(1),j)==0
                            NFC_pixel(in,j)=1;
                        end
                    end
                    
                end
            end
        end
    end
end
NFC_pixel=bwareaopen(NFC_pixel,10);
IPLGCL_NFL=NFC_pixel;


     
%%
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ONL/OPL, OPL/INL and INL/IPL+GCL boundaries %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% FIltering By V and S pixel
I=I(:,:,1);
image=I(150:400,:,1);
Nfilter=6;
Denoisedimage=DenoisingFunction( image,Nfilter );
% figure,imshow(Denoisedimage);
Binaryimage=Denoisedimage;
Binary_edge=edge(Binaryimage,'canny');
dim=size(Binary_edge);
for i=1:dim(1)
    imax=min(i+15,dim(1));
    imin=min(i+1:dim(1));
    for j=1:dim(2)
         if V_pixel(i,j)==1
            Binary_edge(imin:dim(1),j)=0;
         end
         if ISOS_pixel(i,j)==1
            Binary_edge(1:imax,j)=0;
         end
    end
    
end
Binary_alledge=Binary_edge+V_pixel+ISOS_pixel+NFC_pixel;
Binary_alledge=bwareaopen(Binary_alledge,5);
Binary_alledge=bwmorph(Binary_alledge,'thin',inf);
%%% Vertical Clearing %%%%%%%%%%%%%%%%%%%%%%%%%%
w=3;
edge_enhanced_vertical_cleared=Binary_alledge;
for j=1:dim(2)
    for i=1:dim(1)
        imax=min(w+i,dim(1));
        if edge_enhanced_vertical_cleared(i:imax,j)==1
        edge_enhanced_vertical_cleared(i:imax,j)=0;
        end
    end
end
Binary_alledge=edge_enhanced_vertical_cleared;
Binary_alledge=bwareaopen(Binary_alledge,15);
 %figure, imshow(Binary_alledge);

 



%% DATA Cloud provider ALL LAyers :
% im_clear=Binary_edge+V_pixel+ISOS_pixel;
% [r,c]=find(Shorten(:,:,1));
% dim=size(r);
% 
% Order=1:dim;
% Order=Order';
% Ones=ones(dim);
% y=ones(dim);
% y(:,1)=25;
% tex(:,1)=Order(:,1)+3040;
% tex(:,2)=c(:,1);
% tex(:,3)=y(:,1);
% tex(:,4)=r(:,1);
% tex(:,5)=Ones(:,1);
% tex(:,6)=Ones(:,1);
% tex(:,7)=Ones(:,1);
% 
% myfile=fopen('slide_1_26_Data_morefaces.txt','w');
% count = 0;
% %   while ischar(fgetl(myfile))
% %     count = count + 1;
% %   end
% %  tex(:,1)= tex(:,1)+count;
% for i=1:dim
%     fprintf(myfile,'\n%d %d %d %d %d %d %d',tex(i,1),tex(i,2),tex(i,3),tex(i,4),tex(i,5),tex(i,6),tex(i,7));
%   
% end

%%
%% Data Claud provider Writing Only Viterous/Retina && RPE+IS+OS/ONL boudaries 
% % 
% Onlyfaces=V_pixel+ISOS_pixel;
% TwFaceShorten1=zeros(size(Onlyfaces));
% for i=1:dim(1)
%     for j=1:20:dim(2)
%         
%             TwFaceShorten1(i,j)=Onlyfaces(i,j);
%         
%     end
% end
% figure,imshow(TwFaceShorten1);
% [r,c]=find(TwFaceShorten1);
% dim=size(r);
% 
% Order=1:dim;
% Order=Order';
% Ones=ones(dim);
% y=ones(dim);
% y(:,1)=10;
% tex2(:,1)=Order(:,1);
% tex2(:,2)=c(:,1);
% tex2(:,3)=y(:,1);
% tex2(:,4)=r(:,1);
% tex2(:,5)=Ones(:,1);
% tex2(:,6)=Ones(:,1);
% tex2(:,7)=Ones(:,1);
% 
% myfile=fopen('slide_9_10_only_faces.txt','a+');
% count = 0;
%   while ischar(fgetl(myfile))
%     count = count + 1;
%   end
%  tex2(:,1)= tex2(:,1)+count;
% for i=1:dim
%     fprintf(myfile,'\n%d %d %d %d %d %d %d',tex2(i,1),tex2(i,2),tex2(i,3),tex2(i,4),tex2(i,5),tex2(i,6),tex2(i,7));
%   
% end
% 
% fclose(myfile);
% 
% 
% 


%% 
% % % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   IPL+GCL/NFL Boundary %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% % % % %%%%%%%%%%%%%% Finding pixel
% RGC_pixel=zeros(size(Binaryimage));
% 
% for i=dim(1):-1:1
%     for j=1:dim(2)
%         if NFC_pixel(i,j)==1
%             for in=i-1:-1:1
%                 if (im_clear(in,j)==1)
%                     imin=max(i-8,1);%%% Distance from RGC layer
%                     imax=min(1,i-10);%%% Distance from RGC layer
%                     if in<imin && i>imax
%                         if RGC_pixel(in+1:dim(1),j)==0 
%                             RGC_pixel(in,j)=1;
%                         end
%                     end
%                 end
%             end
%         end
%     end
% end
% 
% RGC_pixel=bwareaopen(RGC_pixel,15);
% IPLGCL_NFL=RGC_pixel;
%%
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Finding ONL/OPL %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
OPL_pixel=zeros(size(Binaryimage));
for i=1:dim(1)
    for j=1:dim(2)
        if ISOS_pixel(i,j)==1
            for in=i+10:dim(1)   
                if (Binaryimage(in,j)==1)
                    if OPL_pixel(1:in,j)==0
                        OPL_pixel(in,j)=1;
                    end
                end
            end
        end
    end
end
OPL_pixel=bwareaopen(OPL_pixel,10); 
ONL_OPL=OPL_pixel;
%figure, imshow(OPL_pixel); 


%%%% LIkning
% for i=1:dim(1)
%     for j=1:dim(2)
%         imin=max(1,i-1);
%         imax=min(i+1,dim(1));
%         jmin=min(j+1,dim(2));
%         jmax=min(j+2,dim(2));
%         if OPL_pixel(i,j)==1
%             if(OPL_pixel(imin:imax,jmin:jmax)==0)
%                 [r4,c4]=find(OPL_pixel(1:dim(1),jmin:dim(2)));
%                 if ~(isempty(c4))
%                     dimr=size(r4);
%                     dis=zeros(dimr(1),1);
%                     for s=1:dimr(1)
%                         dis(s)=abs(i-r4(s))+c4(s);
%                     end
%                     indexmin=find(min(dis)==dis,1);
%                     jindex=min(dim(2),jmin+c4(indexmin));
%                     rpts = linspace(i,r4(indexmin));
%                     cpts = linspace(jmin,jindex);
%                     index = sub2ind(dim,round(rpts),round(cpts));
%                     OPL_pixel(index)=255;
%                 end
%             end
%         end
%     end
% end
% figure, imshow(OPL_pixel); 
% OPL_pixel=imclose(OPL_pixel,strel('rectangle',[1,10]));
%% Shorting: data caud provider from ONL/OPL

OPL(:,:)=OPL_pixel;
dim=size(OPL);
shorten_OPL=zeros(dim);
for i=1:dim(1)
    for j=1:25:dim(2)
        
            shorten_OPL(i,j)=OPL(i,j);
        
    end
end
% figure,imshow(A(:,:));
Shorten_OPL(:,:,1)=shorten_OPL(:,:,1);
% figure,imshow(Shorten_OPL(:,:,1));
 [r,c]=find(Shorten_OPL);
OPL=[r,c];

%% Data caud provider all layers
 B=Shorten_OPL+Shorten_RPE+Shorten_ISOS+Shorten_Vitreous;
 figure,imshow(B);
 
 
 [r,c]=find(B);
dim=size(r);

Order=1:dim;
Order=Order';
Ones=ones(dim);
y=ones(dim);
y(:,1)=26*50;
tex2(:,1)=Order(:,1);
tex2(:,2)=c(:,1);
tex2(:,3)=y(:,1);
tex2(:,4)=r(:,1);
tex2(:,5)=Ones(:,1);
tex2(:,6)=Ones(:,1);
tex2(:,7)=Ones(:,1);

% myfile=fopen('Data_All_Layer.txt','a+');
% count = 0;
%   while ischar(fgetl(myfile))
%     count = count + 1;
%   end
%  tex2(:,1)= tex2(:,1)+count;
% for i=1:dim
%     fprintf(myfile,'\n%d %d %d %d %d %d %d',tex2(i,1),tex2(i,2),tex2(i,3),tex2(i,4),tex2(i,5),tex2(i,6),tex2(i,7));
%   
% end
% 
% fclose(myfile);
% %  
%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Finding OPL/INL
% INL_pixel=zeros(size(Binaryimage));
% for i=dim(1):-1:1
%     for j=1:dim(2)
%         if OPL_pixel(i,j)==1
%             for in=i+3:dim(1)
%                 if (im_clear(in,j)==1)
%                     if INL_pixel(1:in-1,j)==0 
%                         INL_pixel(in,j)=1;
%                     end
%                 end
%             end
%         end
%         
%     end
% end
% OPL_INL=INL_pixel;
% %%
% % % % % % % % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Showing Different Layers %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% connected_layers=V_pixel+ISOS_pixel+RPE_pixel+RGC_pixel+OPL_pixel+NFC_pixel+INL_pixel;
% connected_layers=bwareaopen(connected_layers,3);
% connected_layers=imclose(connected_layers,strel('rectangle',[1,15]));
% connected_layers=imdilate(connected_layers,strel('disk',1));
% connected_layers_thin=bwmorph(connected_layers,'thin',inf);
% connected_layers_thin=bwareaopen(connected_layers_thin,15);
 % SecondDetectedEdges=connected_layers_thin;
% close(h)