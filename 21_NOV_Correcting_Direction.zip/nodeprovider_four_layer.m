myfile=fopen('nodes_vitreous.txt','w');


n=36; %%% The number of nodes in each slides

%%%% Defineing the place of node by data provided by each boundary
ynode=zeros(n);

rows=size(Vitr);
firstincrease=floor(size(Vitr)/4);
secondincrease=floor(firstincrease(1,1)/2);
thirdincrease=floor(secondincrease/2);
ynode(1,1)=Vitr(1,1);
ynode(2,2)=Vitr(firstincrease(1,1),1);
ynode(3,3)=Vitr(firstincrease(1,1)+secondincrease,1);
ynode(4,4)=Vitr(firstincrease(1,1)+secondincrease+thirdincrease,1);
ynode(5,5)=Vitr(2*firstincrease(1,1),1);
ynode(6,6)=Vitr(2*firstincrease(1,1)+thirdincrease,1);
ynode(7,7)=Vitr(2*firstincrease(1,1)+secondincrease,1);
ynode(8,8)=Vitr(3*firstincrease(1,1),1);
ynode(9,9)=Vitr(rows(1),1);

firstincrease=floor(size(OPL)/4);
secondincrease=floor(firstincrease(1,1)/2);
thirdincrease=floor(secondincrease/2);
rows2=size(OPL);

ynode(10,10)=OPL(1,1);
ynode(11,11)=OPL(firstincrease(1,1),1);
ynode(12,12)=OPL(firstincrease(1,1)+secondincrease,1);
ynode(13,13)=OPL(firstincrease(1,1)+secondincrease+thirdincrease,1);
ynode(14,14)=OPL(2*firstincrease(1,1),1);
ynode(15,15)=OPL(2*firstincrease(1,1)+thirdincrease,1);
ynode(16,16)=OPL(2*firstincrease(1,1)+secondincrease,1);
ynode(17,17)=OPL(3*firstincrease(1,1),1);
ynode(18,18)=OPL(rows2(1),1);


firstincrease=floor(size(ISOS)/4);
secondincrease=floor(firstincrease(1,1)/2);
thirdincrease=floor(secondincrease/2);
rows2=size(ISOS);

ynode(19,19)=ISOS(1,1);
ynode(20,20)=ISOS(firstincrease(1,1),1);
ynode(21,21)=ISOS(firstincrease(1,1)+secondincrease,1);
ynode(22,22)=ISOS(firstincrease(1,1)+secondincrease+thirdincrease,1);
ynode(23,23)=ISOS(2*firstincrease(1,1),1);
ynode(24,24)=ISOS(2*firstincrease(1,1)+thirdincrease,1);
ynode(25,25)=ISOS(2*firstincrease(1,1)+secondincrease,1);
ynode(26,26)=ISOS(3*firstincrease(1,1),1);
ynode(27,27)=ISOS(rows2(1),1);


firstincrease=floor(size(RPE)/4);
secondincrease=floor(firstincrease(1,1)/2);
thirdincrease=floor(secondincrease/2);
rows2=size(RPE);

ynode(28,28)=RPE(1,1);
ynode(29,29)=RPE(firstincrease(1,1),1);
ynode(30,30)=RPE(firstincrease(1,1)+secondincrease,1);
ynode(31,31)=RPE(firstincrease(1,1)+secondincrease+thirdincrease,1);
ynode(32,32)=RPE(2*firstincrease(1,1),1);
ynode(33,33)=RPE(2*firstincrease(1,1)+thirdincrease,1);
ynode(34,34)=RPE(2*firstincrease(1,1)+secondincrease,1);
ynode(35,35)=RPE(3*firstincrease(1,1),1);
ynode(36,36)=RPE(rows2(1),1);


%%% HAving same X position for all nodes to have staight cube in first
%%% place

x=zeros(n);
for i=1:4
x(1+(i-1)*9,1+(i-1)*9)=26;
x(2+(i-1)*9,2+(i-1)*9)=241;
x(3+(i-1)*9,3+(i-1)*9)=361;
x(4+(i-1)*9,4+(i-1)*9)=421;
x(5+(i-1)*9,5+(i-1)*9)=481;
x(6+(i-1)*9,6+(i-1)*9)=541;
x(7+(i-1)*9,7+(i-1)*9)=601;
x(8+(i-1)*9,8+(i-1)*9)=721;
x(9+(i-1)*9,9+(i-1)*9)=1001;
end





% 
% fprintf(myfile,' CMISS Version 1.21 ipnode File Version 2 \n Heading:\n \n The number of nodes is [    1]: %2d \n Number of coordinates [2]: 3',36);
% fprintf(myfile,'\n Do you want prompting for different versions of nj=1 [N]? N ');
% fprintf(myfile,'\n Do you want prompting for different versions of nj=2 [N]? N ');
% fprintf(myfile,'\n Do you want prompting for different versions of nj=3 [N]? N ');
% fprintf(myfile,'\n The number of derivatives for coordinate 1 is [0]: 0');
% fprintf(myfile,'\n The number of derivatives for coordinate 2 is [0]: 0 \n');
% fprintf(myfile,'\n The number of derivatives for coordinate 3 is [0]: 0 \n');

for i=1:n
    fprintf(myfile,'\n Node number [    %2d]: %2d',i+12*36,i+12*36); %(number of slide-1)*n+i
    fprintf(myfile,'\n The Xj(1) coordinate is [ 0.00000E+00]: %2d ',x(i,i));
    fprintf(myfile,'\n The Xj(2) coordinate is [ 0.00000E+00]: -15');
    fprintf(myfile,'\n The Xj(3) coordinate is [ 0.00000E+00]: %2d \n ',ynode(i,i));
end
    
fclose(myfile);


















