x=[26 241 361 421 481 541 601 721 1001];
y=[50 200 300 450 550 650 750 850 950 1050 1200 1300];
Node=[x(1),y;x(2),y;x(3),y;x(4),y;x(5),y;x(6),y;x(7),y;x(8),y;x(9),y];
z=300;
myfile=fopen('nodes_vitreous.txt','w');
for j=1:12
    for i=1:9
        fprintf(myfile,'\n Node number [    %2d]: %2d',432+i+(j-1)*9,432+i+(j-1)*9); %(number of slide-1)*n+i
        fprintf(myfile,'\n The Xj(1) coordinate is [ 0.00000E+00]: %2d ',x(1,i));
        fprintf(myfile,'\n The Xj(2) coordinate is [ 0.00000E+00]: %2d',y(1,j));
        fprintf(myfile,'\n The Xj(3) coordinate is [ 0.00000E+00]: %2d \n ',z);
    end
end
fclose(myfile);
