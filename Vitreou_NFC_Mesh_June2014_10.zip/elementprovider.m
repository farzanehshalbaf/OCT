myfile=fopen('element_including_vitreous.txt','w');
ne=8; %%% Number of element between each two boundary
row=2; %% Number of boundary in each slide
NS=12; %%% Number of all slides for providing node
NnB=9; %% number of nodes in each boundary
NeS=8; %number of elements between each two slides
NnS=18; %number of nodes in each slide

 fprintf(myfile,' MISS Version 1.21 ipelem File Version 2 \n Heading: \n \n The number of elements is [1]: %2d ',(n*(row-1))*(NS-1));
% for j=1:NS-1
%     for r=1:(row-1) 
%             for i=1:n
%                 fprintf(myfile,'\n \n Element number [    %2d]: %2d',i+(r-1)*ne+(j-1)*NeS,i+(r-1)*ne+(j-1)*NeS);
%                 fprintf(myfile,'\n The number of geometric Xj-coordinates is [2]: 3 \n The basis function type for geometric variable 1 is [1]: 1 \n The basis function type for geometric variable 2 is [1]: 1 \n The basis function type for geometric variable 3 is [1]: 1');
%                 fprintf(myfile,'\n Enter the 8 global numbers for basis 1: %2d %2d %2d %2d %2d %2d %2d %2d',1,2,NnB+1,NnB+2,(NS-1)*NnS+1,(NS-1)*NnS+2,(NS-1)*NnS+NnB+1+(NS-1)*NnS+NnB+2);
%             end
%     end
% end

for j=1:NS-1
    for r=1:(row-1) 
            for i=1:n
                fprintf(myfile,'\n \n Element number [    %2d]: %2d',i+(r-1)*ne+(j-1)*NeS,i+(r-1)*ne+(j-1)*NeS);
                fprintf(myfile,'\n The number of geometric Xj-coordinates is [2]: 3 \n The basis function type for geometric variable 1 is [1]: 1 \n The basis function type for geometric variable 2 is [1]: 1 \n The basis function type for geometric variable 3 is [1]: 1');
                fprintf(myfile,'\n Enter the 8 global numbers for basis 1: %2d %2d %2d %2d %2d %2d %2d %2d',1+(i-1)+(r-1)*NnB+(j-1)*NnS,2+(i-1)+(r-1)*NnB+(j-1)*NnS,19+(i-1)+(r-1)*NnB+(j-1)*NnS,20+(i-1)+(r-1)*NnB+(j-1)*NnS,10+(i-1)+(r-1)*NnB+(j-1)*NnS,11+(i-1)+(r-1)*NnB+(j-1)*NnS,28+(i-1)+(r-1)*NnB+(j-1)*NnS,29+(i-1)+(r-1)*NnB+(j-1)*NnS);
            end
    end
end
%%% 9 is because of number of nodes in eaxh boudary
%%% 36 is because of number of elements between each two slides
