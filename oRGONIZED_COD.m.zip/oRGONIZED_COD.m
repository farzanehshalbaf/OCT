close all;
clear all

Sampling_rate=30;
S=Sampling_rate;
Distance_Between_Slides=2;
D=Distance_Between_Slides;
n=36; %%% The number of nodes in each slides
NS=12; %%% Please specify the number of slide for node here
I=imread('croped16.jpg');
Number_of_Slide=26;
Ad=I(150:400,:,1);
h = waitbar(0,'Please wait...');
%%
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Finding Vitreous/Retina %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Ad=imadjust(Ad,stretchlim(Ad));
A_edge=edge(Ad,'canny',[0.1,0.5]);
dim=size(Ad);

% %%% Vertical Clearing %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% This is to clear any edges caused by outline of the image
w=3;
Binary_vertical_cleared=A_edge;

for j=1:dim(2)
    for i=1:dim(1)
        imax=min(w+i,dim(1));
        if Binary_vertical_cleared(i:imax,j)==1
        Binary_vertical_cleared(i:imax,j)=0;
        end
    end
end

% %%%%% Finding Vitreous Boundary Pixels %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% The vitreous/Retina pixels are the first detected borders from the
%%% bottom of the image


Vitreous_retina_pixel=zeros(dim);

for i=dim(1):-1:1
    for j=1:dim(2)
        if (Binary_vertical_cleared(i,j)==1)
            if (Vitreous_retina_pixel(i+1:dim(1),j)==0)
            Vitreous_retina_pixel(i,j)=1;
            
            end
        end
    end
end
 Vitreous_retina_pixel=bwareaopen(Vitreous_retina_pixel,10);

% % % % %%%%%%%%%%%% Vitreous Linking %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Sometimes there is a chance of discountiniuity alonng the boundary 
%%% because of low resolution. here they are connected by finding the first
%%% on pixels located in neighbour of 30 pixels   
for i=1:dim(1)
    for j=1:dim(2)
        imin=max(1,i-3);
        imax=min(i+3,dim(1));
        jmin=min(j+1,dim(2));
        jmax=min(j+2,dim(2));
        if Vitreous_retina_pixel(i,j)==1
            if(Vitreous_retina_pixel(imin:imax,jmin:jmax)==0)
                [r4,c4]=find(Vitreous_retina_pixel(1:dim(1),jmin:dim(2)));
                if ~(isempty(c4))
                    dimr=size(r4);
                    dis=zeros(dimr(1),1);
                    for s=1:dimr(1)
                        dis(s)=abs(i-r4(s))+c4(s);
                    end
                    indexmin=find(min(dis)==dis,1);
                    if abs(i-r4(indexmin))<30
                        jindex=min(dim(2),jmin+c4(indexmin));
                        rpts = linspace(i,r4(indexmin));
                        cpts = linspace(jmin,jindex);
                        index = sub2ind(dim,round(rpts),round(cpts));
                        Vitreous_retina_pixel(index)=255;
                    end
                end
            end
        end
    end
end
Vitreous_retina_pixel=imdilate(Vitreous_retina_pixel,strel('disk',3));
Vitreous_retina_pixel=bwmorph(Vitreous_retina_pixel,'thin',inf);
Vitreous_retina_pixel=bwareaopen(Vitreous_retina_pixel,50);
% Vitreous=V_pixel;

waitbar(0.2);

%% 
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Finding RPE+IS+OS/ONL %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

A_edge=edge(Ad, 'canny', [0.2,0.6]);

%%%%%%% Vertical Clearing %%%%%%%%%%%%%%%%%%%%%%%%
w=3;
A_vertical_cleared=A_edge;

for j=1:dim(2)
    for i=1:dim(1)
        imax=min(w+i,dim(1));
        if A_vertical_cleared(i:imax,j)==1
        A_vertical_cleared(i:imax,j)=0;
        end
    end
end
A=bwmorph(A_vertical_cleared,'bridge',inf);
A=bwareaopen(A,20);

%%%%%%% pixel 

RPE_ISOS_pixel=zeros(dim);

for i=1:dim(1)
    imin=max(i-1, 1);
    for j=1:dim(2)
        if (Vitreous_retina_pixel(i,j)==1)
            for in=imin:-1:1
                if (A(in,j)==1)
                    if   in<i-35
                        if (RPE_ISOS_pixel(in+1:dim(1),j)==0)
                            RPE_ISOS_pixel(in,j)=1;
                        end
                    end
                end
            end
        end
    end
end
 RPE_ISOS_pixel=bwareaopen(RPE_ISOS_pixel,15);
% % % %%%%% Second layer Linking
 for i=1:dim(1)
     for j=1:dim(2)
         imin=max(1,i-1);
         imax=min(i+1,dim(1));
         jmin=min(j+1,dim(2));
         jmax=min(j+2,dim(2));
         if RPE_ISOS_pixel(i,j)==1
             if(RPE_ISOS_pixel(imin:imax,jmin:jmax)==0)
                 [r4,c4]=find(RPE_ISOS_pixel(1:dim(1),jmin:dim(2)));
                 if ~(isempty(c4))
                     dimr=size(r4);
                     dis=zeros(dimr(1),1);
                     for s=1:dimr(1)
                         dis(s)=abs(i-r4(s))+c4(s);
                     end
                     indexmin=find(min(dis)==dis,1);
                     if abs(i-r4(indexmin))<10
                         jindex=min(dim(2),jmin+c4(indexmin));
                         rpts = linspace(i,r4(indexmin));
                         cpts = linspace(jmin,jindex);
                         index = sub2ind(dim,round(rpts),round(cpts));
                         RPE_ISOS_pixel(index)=255;
                     end
                 end
             end
         end
     end
 end
RPE_ISOS_pixel=bwareaopen(RPE_ISOS_pixel,20);
waitbar(0.4);

%%
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Finding Chroid/RPE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %%%%%%%% Pre Processing %%%%%%%%%%%%
M=medfilt2(Ad,[5,10]);
A_edge=edge(M,'canny',[0.2,0.25]);
%%%%%%% Finding First Layer Pixel%%%%%%%%%%%%%%%%%
Choroid_RPE_pixel=zeros(dim);

 for i=1:dim(1)
     for j=1:dim(2)
         if (RPE_ISOS_pixel(i,j)==1)
            for in=i-2:-1:1
                if A_edge(in,j)==1
                    if  in>i-23 && in<i-13
                        if (Choroid_RPE_pixel(in:dim(1),j)==0)
                            Choroid_RPE_pixel(in,j)=1;
                        end
                    end
                end
            end
         end
     end
 end
Choroid_RPE_pixel=bwareaopen(Choroid_RPE_pixel,10);
% % %%%%% First layer Linking
for i=1:dim(1)
    for j=1:dim(2)
        imin=max(1,i-1);
        imax=min(i+1,dim(1));
        jmin=min(j+1,dim(2));
        jmax=min(j+2,dim(2));
        if Choroid_RPE_pixel(i,j)==1
            if(Choroid_RPE_pixel(imin:imax,jmin:jmax)==0)
                [r4,c4]=find(Choroid_RPE_pixel(1:dim(1),jmin:dim(2)));
                if ~(isempty(c4))
                    dimr=size(r4);
                    dis=zeros(dimr(1),1);
                    for s=1:dimr(1)
                        dis(s)=abs(i-r4(s))+c4(s);
                    end
                    indexmin=find(min(dis)==dis,1);
                    jindex=min(dim(2),jmin+c4(indexmin));
                    rpts = linspace(i,r4(indexmin));
                    cpts = linspace(jmin,jindex);
                    index = sub2ind(dim,round(rpts),round(cpts));
                    Choroid_RPE_pixel(index)=255;
                end
            end
        end
    end
end

waitbar(0.6);
%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% IPL+GCL/NFL Boundary %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % %%%%%%% Pre Processing
[Denoisedimage,im_enhanced]=DenoisingFunction( Ad,4 );
im_enhanced=medfilt2(im_enhanced,[3,10]);
im_enhanced=imadjust(im_enhanced,stretchlim(im_enhanced)); 
edge_enhanced=edge(im_enhanced,'canny',[0.2,0.3]);

% %%%%%%%%% Filtering By vitreous and Second Layer
 
for i=1:dim(1)
    for j=1:dim(2)
         if Vitreous_retina_pixel(i,j)==1
            imin=min(dim(1),i+10);
            edge_enhanced(imin:dim(1),j)=0;
         end
         imax=min(i-50,1);
         if RPE_ISOS_pixel(i,j)==1
             edge_enhanced(1:imax)=0;
         end
       
    end
    
end
 
%%% Vertical Clearing %%%%%%%%%%%%%%%%%%%%%%%%%%
w=3;
edge_enhanced_vertical_cleared=edge_enhanced;

for j=1:dim(2)
    for i=1:dim(1)
        imax=min(w+i,dim(1));
        if edge_enhanced_vertical_cleared(i:imax,j)==1
        edge_enhanced_vertical_cleared(i:imax,j)=0;
        end
    end
end

% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Finidng NFC_pixel %%%%%%%%%%%%

NFC_pixel=zeros(dim);

for i=dim(1):-1:1
    for j=1:dim(2)
        if Vitreous_retina_pixel(i,j)==1
            for in=i-4:-1:1
                if edge_enhanced(in,j)==1
                    if in<imin 
                        if NFC_pixel(in:dim(1),j)==0
                            NFC_pixel(in,j)=1;
                        end
                    end
                    
                end
            end
        end
    end
end
NFC_pixel=bwareaopen(NFC_pixel,10);

waitbar(0.8);
%%
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ONL/OPL, OPL/INL and INL/IPL+GCL boundaries %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% FIltering By V and S pixel
[Denoisedimage,im_enhanced]=DenoisingFunction( Ad,6 );
Binary_edge=edge(Denoisedimage,'canny');
for i=1:dim(1)
    imax=min(i+15,dim(1));
    imin=min(i+1:dim(1));
    for j=1:dim(2)
         if Vitreous_retina_pixel(i,j)==1
            Binary_edge(imin:dim(1),j)=0;
         end
         if RPE_ISOS_pixel(i,j)==1
            Binary_edge(1:imax,j)=0;
         end
    end
    
end
Binary_alledge=Binary_edge+Vitreous_retina_pixel+RPE_ISOS_pixel+NFC_pixel+Choroid_RPE_pixel;
Binary_alledge=bwareaopen(Binary_alledge,5);
Binary_alledge=bwmorph(Binary_alledge,'thin',inf);

%%% Vertical Clearing %%%%%%%%%%%%%%%%%%%%%%%%%%
w=3;
edge_enhanced_vertical_cleared=Binary_alledge;
for j=1:dim(2)
    for i=1:dim(1)
        imax=min(w+i,dim(1));
        if edge_enhanced_vertical_cleared(i:imax,j)==1
        edge_enhanced_vertical_cleared(i:imax,j)=0;
        end
    end
end
Binary_alledge=edge_enhanced_vertical_cleared;
Binary_alledge=bwareaopen(Binary_alledge,15);
First_DetectedEdges=Binary_alledge;
im_clear=Binary_edge+Vitreous_retina_pixel+RPE_ISOS_pixel;
%% 
% % % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   IPL+GCL/NFL Boundary %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% % % %%%%%%%%%%%%%% Finding pixel
IPL_GCL_NFL_pixel=zeros(size(Denoisedimage));

for i=dim(1):-1:1
    for j=1:dim(2)
        if NFC_pixel(i,j)==1
            for in=i-1:-1:1
                if (im_clear(in,j)==1)
                    imin=max(i-8,1);%%% Distance from RGC layer
                    imax=min(1,i-10);%%% Distance from RGC layer
                    if in<imin && i>imax
                        if IPL_GCL_NFL_pixel(in+1:dim(1),j)==0 
                            IPL_GCL_NFL_pixel(in,j)=1;
                        end
                    end
                end
            end
        end
    end
end

IPL_GCL_NFL_pixel=bwareaopen(IPL_GCL_NFL_pixel,15);
%%
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Finding ONL/OPL %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ONL_OPL_pixel=zeros(size(Denoisedimage));
for i=1:dim(1)
    for j=1:dim(2)
        if RPE_ISOS_pixel(i,j)==1
            for in=i+10:dim(1)   
                if (im_clear(in,j)==1)
                    if ONL_OPL_pixel(1:in,j)==0
                        ONL_OPL_pixel(in,j)=1;
                    end
                end
            end
        end
    end
end
ONL_OPL_pixel=bwareaopen(ONL_OPL_pixel,10); 
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Finding OPL/INL
OPL_INL_pixel=zeros(size(Denoisedimage));
for i=dim(1):-1:1
    for j=1:dim(2)
        if ONL_OPL_pixel(i,j)==1
            for in=i+3:dim(1)
                if (im_clear(in,j)==1)
                    if OPL_INL_pixel(1:in-1,j)==0 
                        OPL_INL_pixel(in,j)=1;
                    end
                end
            end
        end
        
    end
end
%%
% % % % % % % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Showing Different Layers %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

connected_layers=Vitreous_retina_pixel+RPE_ISOS_pixel+Choroid_RPE_pixel+IPL_GCL_NFL_pixel+ONL_OPL_pixel+NFC_pixel+OPL_INL_pixel;
connected_layers=bwareaopen(connected_layers,3);
connected_layers=imclose(connected_layers,strel('rectangle',[1,15]));
connected_layers=imdilate(connected_layers,strel('disk',1));
connected_layers_thin=bwmorph(connected_layers,'thin',inf);
connected_layers_thin=bwareaopen(connected_layers_thin,15);
figure,imshow (connected_layers);
Second_Detected_Edge=connected_layers_thin;
close(h);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% sAMPLING %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% 
%% Sampling Vitreous_retina_pixel
Shorten_Vitreous=zeros(size(Vitreous_retina_pixel));
dim=size(Vitreous_retina_pixel);
for i=1:dim(1)
    for j=1:S:dim(2)
        
            Shorten_Vitreous(i,j)=Vitreous_retina_pixel(i,j);
        
    end
end
[r,c]=find(Shorten_Vitreous);
Vitr=[r,c];

%%
%%% sampling the RPE_ISOS_pixel
ISOS(:,:)=RPE_ISOS_pixel;
dim=size(ISOS);
shorten_ISOS=zeros(dim);
for i=1:dim(1)
    for j=1:S:dim(2)
        
            shorten_ISOS(i,j)=ISOS(i,j);
        
    end
end
Shorten_ISOS(:,:,1)=shorten_ISOS(:,:,1);
[r,c]=find(Shorten_ISOS);
ISOS=[r,c];
%%
%%% sampling Choroid/RPE
RPE(:,:)=Choroid_RPE_pixel;
dim=size(RPE);
shorten_RPE=zeros(dim);
for i=1:dim(1)
    for j=1:S:dim(2)
        
            shorten_RPE(i,j)=RPE(i,j);
        
    end
end
Shorten_RPE(:,:,1)=shorten_RPE(:,:,1);
[r,c]=find(Shorten_RPE);
RPE=[r,c];
%%

OPL(:,:)=ONL_OPL_pixel;
dim=size(OPL);
shorten_OPL=zeros(dim);
for i=1:dim(1)
    for j=1:S:dim(2)
        
            shorten_OPL(i,j)=OPL(i,j);
        
    end
end
Shorten_OPL(:,:,1)=shorten_OPL(:,:,1);
 [r,c]=find(Shorten_OPL);
OPL=[r,c];
%%
%%% Wrinting the sampled data in a text file. Remember you should define the
%%% number of slide at the begining

Sampled_image= Shorten_Vitreous+Shorten_ISOS+Shorten_RPE+Shorten_OPL;
figure, imshow (Sampled_image)
[r,c]=find(Sampled_image);
dim=size(r);
Order=1:dim;
Order=Order';
Ones=ones(dim);
y=ones(dim);
y(:,1)=Number_of_Slide*D;
tex2(:,1)=Order(:,1);
tex2(:,2)=c(:,1);
tex2(:,3)=y(:,1);
tex2(:,4)=r(:,1);
tex2(:,5)=Ones(:,1);
tex2(:,6)=Ones(:,1);
tex2(:,7)=Ones(:,1);

myfile=fopen('3D_DataCloud.txt','a+');
count = 0;
  while ischar(fgetl(myfile))
    count = count + 1;
  end
 tex2(:,1)= tex2(:,1)+count;
for i=1:dim
    fprintf(myfile,'\n%d %12f %12f %12f %d %d %d',tex2(i,1),tex2(i,2),tex2(i,3),tex2(i,4)-2,tex2(i,5),tex2(i,6),tex2(i,7));
  
end

fclose(myfile);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

myfile_2=fopen('Nodes.txt','a+');
%%%% Defineing the place of node by data provided by each boundary
ynode=zeros(n);

rows=size(Vitr);
firstincrease=floor(size(Vitr)/4);
secondincrease=floor(firstincrease(1,1)/2);
thirdincrease=floor(secondincrease/2);
ynode(1,1)=Vitr(1,1);
ynode(2,2)=Vitr(firstincrease(1,1),1);
ynode(3,3)=Vitr(firstincrease(1,1)+secondincrease,1);
ynode(4,4)=Vitr(firstincrease(1,1)+secondincrease+thirdincrease,1);
ynode(5,5)=Vitr(2*firstincrease(1,1),1);
ynode(6,6)=Vitr(2*firstincrease(1,1)+thirdincrease,1);
ynode(7,7)=Vitr(2*firstincrease(1,1)+secondincrease,1);
ynode(8,8)=Vitr(3*firstincrease(1,1),1);
ynode(9,9)=Vitr(rows(1),1);

firstincrease=floor(size(OPL)/4);
secondincrease=floor(firstincrease(1,1)/2);
thirdincrease=floor(secondincrease/2);
rows2=size(OPL);

ynode(10,10)=OPL(1,1);
ynode(11,11)=OPL(firstincrease(1,1),1);
ynode(12,12)=OPL(firstincrease(1,1)+secondincrease,1);
ynode(13,13)=OPL(firstincrease(1,1)+secondincrease+thirdincrease,1);
ynode(14,14)=OPL(2*firstincrease(1,1),1);
ynode(15,15)=OPL(2*firstincrease(1,1)+thirdincrease,1);
ynode(16,16)=OPL(2*firstincrease(1,1)+secondincrease,1);
ynode(17,17)=OPL(3*firstincrease(1,1),1);
ynode(18,18)=OPL(rows2(1),1);


firstincrease=floor(size(ISOS)/4);
secondincrease=floor(firstincrease(1,1)/2);
thirdincrease=floor(secondincrease/2);
rows2=size(ISOS);

ynode(19,19)=ISOS(1,1);
ynode(20,20)=ISOS(firstincrease(1,1),1);
ynode(21,21)=ISOS(firstincrease(1,1)+secondincrease,1);
ynode(22,22)=ISOS(firstincrease(1,1)+secondincrease+thirdincrease,1);
ynode(23,23)=ISOS(2*firstincrease(1,1),1);
ynode(24,24)=ISOS(2*firstincrease(1,1)+thirdincrease,1);
ynode(25,25)=ISOS(2*firstincrease(1,1)+secondincrease,1);
ynode(26,26)=ISOS(3*firstincrease(1,1),1);
ynode(27,27)=ISOS(rows2(1),1);


firstincrease=floor(size(RPE)/4);
secondincrease=floor(firstincrease(1,1)/2);
thirdincrease=floor(secondincrease/2);
rows2=size(RPE);

ynode(28,28)=RPE(1,1);
ynode(29,29)=RPE(firstincrease(1,1),1);
ynode(30,30)=RPE(firstincrease(1,1)+secondincrease,1);
ynode(31,31)=RPE(firstincrease(1,1)+secondincrease+thirdincrease,1);
ynode(32,32)=RPE(2*firstincrease(1,1),1);
ynode(33,33)=RPE(2*firstincrease(1,1)+thirdincrease,1);
ynode(34,34)=RPE(2*firstincrease(1,1)+secondincrease,1);
ynode(35,35)=RPE(3*firstincrease(1,1),1);
ynode(36,36)=RPE(rows2(1),1);


x=zeros(n);
for i=1:4
x(1+(i-1)*9,1+(i-1)*9)=31;
x(2+(i-1)*9,2+(i-1)*9)=241;
x(3+(i-1)*9,3+(i-1)*9)=361;
x(4+(i-1)*9,4+(i-1)*9)=421;
x(5+(i-1)*9,5+(i-1)*9)=481;
x(6+(i-1)*9,6+(i-1)*9)=541;
x(7+(i-1)*9,7+(i-1)*9)=601;
x(8+(i-1)*9,8+(i-1)*9)=721;
x(9+(i-1)*9,9+(i-1)*9)=991;
end

if (NS==1)
    fprintf(myfile_2,' CMISS Version 1.21 ipnode File Version 2 \n Heading:\n \n The number of nodes is [    1]: %2d \n Number of coordinates [2]: 3',36);
    fprintf(myfile_2,'\n Do you want prompting for different versions of nj=1 [N]? N ');
    fprintf(myfile_2,'\n Do you want prompting for different versions of nj=2 [N]? N ');
    fprintf(myfile_2,'\n Do you want prompting for different versions of nj=3 [N]? N ');
    fprintf(myfile_2,'\n The number of derivatives for coordinate 1 is [0]: 0');
    fprintf(myfile_2,'\n The number of derivatives for coordinate 2 is [0]: 0 \n');
    fprintf(myfile_2,'\n The number of derivatives for coordinate 3 is [0]: 0 \n');
end
i=0;
for i=1:n
    fprintf(myfile_2,'\n Node number [    %2d]: %2d',i+(NS-1)*n,i+(NS-1)*n); %(number of slide-1)*n+i
    fprintf(myfile_2,'\n The Xj(1) coordinate is [ 0.00000E+00]: %2d ',x(i,i));
    fprintf(myfile_2,'\n The Xj(2) coordinate is [ 0.00000E+00]: %2d',Number_of_Slide*D);
    fprintf(myfile_2,'\n The Xj(3) coordinate is [ 0.00000E+00]: %2d \n ',ynode(i,i));
end

fclose(myfile_2);





