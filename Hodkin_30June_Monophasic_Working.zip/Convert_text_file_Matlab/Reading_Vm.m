
// this is to read the third column of a text file and ommit everything else
fid=fopen('Nod_472.txt');
dat=textscan(fid,'%*s %*s %f %*[^\n]','HeaderLines',1);
fid = fclose(fid);
Vm= cell2mat(dat);
t=[0:0.25:20]; // the order of time increament
t=t';
z=ones(81);
plot3(t,z(:,1),Vm_472)
z=z+1;
hold
plot3(t,z(:,1),Vm_476)
