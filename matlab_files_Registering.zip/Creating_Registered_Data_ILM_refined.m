close all
clear all
%% This file is to create Data cloud of RPE layer. 
%% we first find the mean of IS_OS of the first slide. Then we find the offset of other files 

Slide_1=xlsread('000124920140722020001oct_l_1.xls'); %% redaing segmented Boundary file

%%%%

My_column=1:256;
My_column=My_column';

IS_OS_1=Slide_1(:,5);

%%% Calculating the mean of the base

IS_OS_1_mean=mean(IS_OS_1);


%% Reading the next slide

numfiles=256;





for k = 139:numfiles
    
  myfilename = sprintf('000124920140722020001oct_l_%d.xls%d.txt', k);
  Slide_128 = xlsread(myfilename);
  Number_of_Current_Slide=k;
  Distance_between_slides=0.023;
  pixel_size=0.004;
  Sampling_Rate=8;
  Number_of_columns_of_the_current_slide=256;
  c=Number_of_columns_of_the_current_slide;
  Number_of_data_in_each_border=32; % Number_of_columns_of_the_current_slide/Sampling_Rate
  DB=Number_of_data_in_each_border;
   %%% Calculating the offset
  IS_OS_2=Slide_128(:,5);
  IS_OS_2_mean=mean(IS_OS_2);
  IS_OS_offset=IS_OS_1_mean-IS_OS_2_mean;
  
  % Reading each boundary from the excel file
  ILM_full=Slide_128(:,1)+IS_OS_offset;
  %% ILM
 ILM=zeros(c,1);
  %z_RPE=zeros(DB,1);
  size_Z=1;
  for i=1:52
      if i==1
      ILM(i)=ILM_full(i,1);
      z_ILM(size_Z)=ILM_full(i,1);
      elseif i==52
          ILM(i)=ILM_full(256,1);
          z_ILM(size_Z)=ILM_full(256,1);
      else
          ILM(i)=ILM_full((i-1)*5,1);
          z_ILM(size_Z)=ILM_full((i-1)*5,1);
      end
      size_Z=size_Z+1;
  end
  z_ILM=z_ILM.*pixel_size;
  %%
  y=[1,5,10,15,20,25,30,35,40,45,50,55,60,65,70,75,80,85,90,95,100,105,110,115,120,125,130,135,140,145,150,155,160,165,170,175,180,185,190,195,200,205,210,215,220,225,230,235,240,245,250,256]; %% we have 256 colums, the sampling rate is 8
  y=y';
  y=y.*pixel_size;
  dim=size(y);
  Ones=ones(dim);  %%% to say the unit of the coordinates in ipdata the 
  x=ones(dim)*Number_of_Current_Slide*Distance_between_slides;
  count = 0;
  myfile=fopen('3D_DataCloud_ILM.txt','a+');
  if k>1
      while ischar(fgetl(myfile))
          count = count + 1;
      end
  end
  for i=1:dim
      fprintf(myfile,'\n%2d %2d %10f %10f %2d %2d %2d',count+i,x(i),y(i),z_ILM(i),Ones(i),Ones(i),Ones(i));
  end
end