close all
clear all
myfile=fopen('vitreous_elements.txt','w');
ne=6; %%% Number of element between each two boundary
row=2; %% Number of boundary in each slide
NS=21; %%% Number of all slides for providing node
NnB=7; %% number of nodes in each boundary

NnS=35; %number of nodes in each slide

%% for the numbers used in the following lines use the nodes number 

for j=1:NS-1
            for i=1:ne
                fprintf(myfile,'\n \n Element number [    %2d]: %2d',i+(j-1)*ne+749);
                fprintf(myfile,'\n The number of geometric Xj-coordinates is [2]: 3 \n The basis function type for geometric variable 1 is [1]: 1 \n The basis function type for geometric variable 2 is [1]: 1 \n The basis function type for geometric variable 3 is [1]: 1');
                fprintf(myfile,'\n Enter the 8 global numbers for basis 1: %2d %2d %2d %2d %2d %2d %2d %2d',1191+(i-1)+(j-1)*7,1198+(i-1)+(j-1)*7,1192+(i-1)+(j-1)*7,1199+(i-1)+(j-1)*7,1+(i-1)+(j-1)*35,36+(i-1)+(j-1)*35,2+(i-1)+(j-1)*35,37+(i-1)+(j-1)*35);
                
            end 
end