close all
clear all

%% This part is to register all nodes based on Slide 1 the IS_OS Boundary

Slide_1=xlsread('000124920140722020001oct_l_1.xls'); %% redaing segmented Boundary file

%%%%

My_column=1:256;
My_column=My_column';
Distance_between_slides=0.023;
pixel_size=0.004;
IS_OS_1=Slide_1(:,5);

%%% Calculating the mean of the base

IS_OS_1_mean=mean(IS_OS_1);


%% Reading the slides to create Nodes
OCT_Slides=[92,100,108,112,116,118,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,148,150,154,158,166,172];%%% these slides will make the x coordinate
Y_Slide=[1,48,58,68,73,78,83,88,93,98,103,108,113,118,123,128,133,138,143,148,153,158,163,168,173,178,183,188,198,208,256];
dim_x=size(OCT_Slides);
dim_y=size(Y_Slide);
number_of_nodes_in_each_slide=5*dim_y(1,2);
number_of_nodes_in_each_boundary=dim_y(1,2);
for i=1:dim_x(1,2)
    myfilename = sprintf('000124920140722020001oct_l_%d.xls%3d.txt', OCT_Slides(1,i));
    Slide_128 = xlsread(myfilename); % reading the excel files thant contains the segmented boundary
    Number_of_Current_Slide=OCT_Slides(1,i); 
    Number_of_Slide__for_Node=i; %%% the numbre of slide that is used for creating the node is not the number of the slide itself!!! see the order of slides in creating the nodes instead
    
    
    %% Calculating the offset of each boundary
    IS_OS_full=Slide_128(:,5);% Reading IS_OS boundary from the current excel file
    IS_OS_2_mean=mean(IS_OS_full);
    IS_OS_offset=IS_OS_1_mean-IS_OS_2_mean;
    %% Adding the Offset to the boundaries
    ILM_full=Slide_128(:,1)+IS_OS_offset;
    IPL_full=Slide_128(:,3)+IS_OS_offset;
    OPL_full=Slide_128(:,4)+IS_OS_offset;
    IS_OS_full=Slide_128(:,5)+IS_OS_offset;
    RPE_full=Slide_128(:,6)+IS_OS_offset;
    %%
    %% Z ILM
    ILM=zeros(dim_y(1,2),1);
    for y_coordinate=1:dim_y(1,2)
        ILM(y_coordinate,1)=ILM_full(Y_Slide(1,y_coordinate),1);
    end
    ILM=ILM*pixel_size;
    %% Z IPL
    IPL=zeros(dim_y(1,2),1);
    for y_coordinate=1:dim_y(1,2)
        IPL(y_coordinate,1)=IPL_full(Y_Slide(1,y_coordinate),1);
    end
    IPL=IPL*pixel_size;
    %% Z OPL
    OPL=zeros(dim_y(1,2),1);
    for y_coordinate=1:dim_y(1,2)
        OPL(y_coordinate,1)=OPL_full(Y_Slide(1,y_coordinate),1);
    end
    OPL=OPL*pixel_size;
    %% Z IS_OS
    IS_OS=zeros(dim_y(1,2),1);
    for y_coordinate=1:dim_y(1,2)
        IS_OS(y_coordinate,1)=IS_OS_full(Y_Slide(1,y_coordinate),1);
    end
    IS_OS=IS_OS*pixel_size;
    %% Z RPE
    RPE=zeros(dim_y(1,2),1);
    for y_coordinate=1:dim_y(1,2)
        RPE(y_coordinate,1)=RPE_full(Y_Slide(1,y_coordinate),1);
    end
    RPE=RPE*pixel_size;
    %% y all boundaries
    y=Y_Slide*pixel_size;
    y=y';
    %% x all boundaries
    x=ones(dim_y(1,2),1);
    x=x*Number_of_Current_Slide*Distance_between_slides;
    %% writing the Node file
    myfile_2=fopen('Nodes_refined_smaller.txt','a+');

    if (Number_of_Slide__for_Node==1)
        fprintf(myfile_2,' CMISS Version 1.21 ipnode File Version 2 \n Heading:\n \n The number of nodes is [    1]: %2d \n Number of coordinates [2]: 3',number_of_nodes_in_each_slide*dim_x(1,2));
        fprintf(myfile_2,'\n Do you want prompting for different versions of nj=1 [N]? N ');
        fprintf(myfile_2,'\n Do you want prompting for different versions of nj=2 [N]? N ');
        fprintf(myfile_2,'\n Do you want prompting for different versions of nj=3 [N]? N ');
        fprintf(myfile_2,'\n The number of derivatives for coordinate 1 is [0]: 0');
        fprintf(myfile_2,'\n The number of derivatives for coordinate 2 is [0]: 0');
        fprintf(myfile_2,'\n The number of derivatives for coordinate 3 is [0]: 0 \n');
    end

    for j=1:number_of_nodes_in_each_boundary
        fprintf(myfile_2,'\n Node number [    %2d]: %2d',j+(Number_of_Slide__for_Node-1)*number_of_nodes_in_each_slide,j+(Number_of_Slide__for_Node-1)*number_of_nodes_in_each_slide); 
        fprintf(myfile_2,'\n The Xj(1) coordinate is [ 0.00000E+00]: %2d ',x(j,1));
        fprintf(myfile_2,'\n The Xj(2) coordinate is [ 0.00000E+00]: %2d',y(j,1));
        fprintf(myfile_2,'\n The Xj(3) coordinate is [ 0.00000E+00]: %2d \n ',ILM(j,1));
    end
    for j=1:number_of_nodes_in_each_boundary
        fprintf(myfile_2,'\n Node number [    %2d]: %2d',j+number_of_nodes_in_each_boundary+(Number_of_Slide__for_Node-1)*number_of_nodes_in_each_slide,j+(Number_of_Slide__for_Node-1)*number_of_nodes_in_each_slide+number_of_nodes_in_each_boundary); 
        fprintf(myfile_2,'\n The Xj(1) coordinate is [ 0.00000E+00]: %2d ',x(j,1));
        fprintf(myfile_2,'\n The Xj(2) coordinate is [ 0.00000E+00]: %2d',y(j,1));
        fprintf(myfile_2,'\n The Xj(3) coordinate is [ 0.00000E+00]: %2d \n ',IPL(j,1));
    end
    for j=1:number_of_nodes_in_each_boundary
        fprintf(myfile_2,'\n Node number [    %2d]: %2d',j+(2*number_of_nodes_in_each_boundary)+(Number_of_Slide__for_Node-1)*number_of_nodes_in_each_slide,j+(Number_of_Slide__for_Node-1)*number_of_nodes_in_each_slide+(2*number_of_nodes_in_each_boundary)); 
        fprintf(myfile_2,'\n The Xj(1) coordinate is [ 0.00000E+00]: %2d ',x(j,1));
        fprintf(myfile_2,'\n The Xj(2) coordinate is [ 0.00000E+00]: %2d',y(j,1));
        fprintf(myfile_2,'\n The Xj(3) coordinate is [ 0.00000E+00]: %2d \n ',OPL(j,1));
    end
    for j=1:number_of_nodes_in_each_boundary
        fprintf(myfile_2,'\n Node number [    %2d]: %2d',j+(3*number_of_nodes_in_each_boundary)+(Number_of_Slide__for_Node-1)*number_of_nodes_in_each_slide,j+(Number_of_Slide__for_Node-1)*number_of_nodes_in_each_slide+(3*number_of_nodes_in_each_boundary)); 
        fprintf(myfile_2,'\n The Xj(1) coordinate is [ 0.00000E+00]: %2d ',x(j,1));
        fprintf(myfile_2,'\n The Xj(2) coordinate is [ 0.00000E+00]: %2d',y(j,1));
        fprintf(myfile_2,'\n The Xj(3) coordinate is [ 0.00000E+00]: %2d \n ',IS_OS(j,1));
    end
    for j=1:number_of_nodes_in_each_boundary
        fprintf(myfile_2,'\n Node number [    %2d]: %2d',j+(4*number_of_nodes_in_each_boundary)+(Number_of_Slide__for_Node-1)*number_of_nodes_in_each_slide,j+(Number_of_Slide__for_Node-1)*number_of_nodes_in_each_slide+(4*number_of_nodes_in_each_boundary)); 
        fprintf(myfile_2,'\n The Xj(1) coordinate is [ 0.00000E+00]: %2d ',x(j,1));
        fprintf(myfile_2,'\n The Xj(2) coordinate is [ 0.00000E+00]: %2d',y(j,1));
        fprintf(myfile_2,'\n The Xj(3) coordinate is [ 0.00000E+00]: %2d \n ',RPE(j,1));
    end

    fclose(myfile_2);
    
    
    myfile=fopen('elements.txt','w');
    row=5; %% Number of boundary in each slide
    NS=dim_x(1,2); %%% Number of all slides for providing node
    NnB=dim_y(1,2); %% number of nodes in each boundary
    NnS=NnB*row; %number of nodes in each slide
    ne=NnB-1; %%% Number of element between each two boundary
    NeS=ne*(row-1); %number of elements between each two slides
    %% for the numbers used in the following lines use the nodes number 
    fprintf(myfile,' CMISS Version 1.21 ipelem File Version 2 \n Heading: \n \n The number of elements is [1]: %2d ',(ne*(row-1))*(NS-1));
    for jj=1:NS-1
     for r=1:(row-1) 
              for ii=1:ne
                  fprintf(myfile,'\n \n Element number [    %2d]: %2d',ii+(r-1)*ne+(jj-1)*NeS,ii+(r-1)*ne+(jj-1)*NeS);
                  fprintf(myfile,'\n The number of geometric Xj-coordinates is [2]: 3 \n The basis function type for geometric variable 1 is [1]: 1 \n The basis function type for geometric variable 2 is [1]: 1 \n The basis function type for geometric variable 3 is [1]: 1');
                  fprintf(myfile,'\n Enter the 8 global numbers for basis 1: %2d %2d %2d %2d %2d %2d %2d %2d',1+(ii-1)+(r-1)*NnB+(jj-1)*NnS,NnS+1+(ii-1)+(r-1)*NnB+(jj-1)*NnS,2+(ii-1)+(r-1)*NnB+(jj-1)*NnS,NnS+2+(ii-1)+(r-1)*NnB+(jj-1)*NnS,NnB+1+(ii-1)+(r-1)*NnB+(jj-1)*NnS,NnS+NnB+1+(ii-1)+(r-1)*NnB+(jj-1)*NnS,NnB+2+(ii-1)+(r-1)*NnB+(jj-1)*NnS,NnS+NnB+2+(ii-1)+(r-1)*NnB+(jj-1)*NnS);
                  fprintf(myfile,'\n Enter the 8 numbers for basis 4 [prev]: %2d %2d %2d %2d %2d %2d %2d %2d',1+(ii-1)+(r-1)*NnB+(jj-1)*NnS,NnS+1+(ii-1)+(r-1)*NnB+(jj-1)*NnS,2+(ii-1)+(r-1)*NnB+(jj-1)*NnS,NnS+2+(ii-1)+(r-1)*NnB+(jj-1)*NnS,NnB+1+(ii-1)+(r-1)*NnB+(jj-1)*NnS,NnS+NnB+1+(ii-1)+(r-1)*NnB+(jj-1)*NnS,NnB+2+(ii-1)+(r-1)*NnB+(jj-1)*NnS,NnS+NnB+2+(ii-1)+(r-1)*NnB+(jj-1)*NnS);
                
              end
     end
    end
   
end


