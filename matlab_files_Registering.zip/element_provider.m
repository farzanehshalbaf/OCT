close all
clear all
myfile=fopen('elements.txt','w');
ne=30; %%% Number of element between each two boundary
row=5; %% Number of boundary in each slide
NS=39; %%% Number of all slides for providing node
NnB=31; %% number of nodes in each boundary
NeS=120; %number of elements between each two slides
NnS=155; %number of nodes in each slide

%% for the numbers used in the following lines use the nodes number 
fprintf(myfile,' CMISS Version 1.21 ipelem File Version 2 \n Heading: \n \n The number of elements is [1]: %2d ',(ne*(row-1))*(NS-1));
for j=1:NS-1
    for r=1:(row-1) 
            for i=1:ne
                fprintf(myfile,'\n \n Element number [    %2d]: %2d',i+(r-1)*ne+(j-1)*NeS,i+(r-1)*ne+(j-1)*NeS);
                fprintf(myfile,'\n The number of geometric Xj-coordinates is [2]: 3 \n The basis function type for geometric variable 1 is [1]: 1 \n The basis function type for geometric variable 2 is [1]: 1 \n The basis function type for geometric variable 3 is [1]: 1');
                fprintf(myfile,'\n Enter the 8 global numbers for basis 1: %2d %2d %2d %2d %2d %2d %2d %2d',1+(i-1)+(r-1)*NnB+(j-1)*NnS,156+(i-1)+(r-1)*NnB+(j-1)*NnS,2+(i-1)+(r-1)*NnB+(j-1)*NnS,157+(i-1)+(r-1)*NnB+(j-1)*NnS,32+(i-1)+(r-1)*NnB+(j-1)*NnS,187+(i-1)+(r-1)*NnB+(j-1)*NnS,33+(i-1)+(r-1)*NnB+(j-1)*NnS,188+(i-1)+(r-1)*NnB+(j-1)*NnS);
                fprintf(myfile,'\n Enter the 8 numbers for basis 4 [prev]: %2d %2d %2d %2d %2d %2d %2d %2d',1+(i-1)+(r-1)*NnB+(j-1)*NnS,156+(i-1)+(r-1)*NnB+(j-1)*NnS,2+(i-1)+(r-1)*NnB+(j-1)*NnS,157+(i-1)+(r-1)*NnB+(j-1)*NnS,32+(i-1)+(r-1)*NnB+(j-1)*NnS,187+(i-1)+(r-1)*NnB+(j-1)*NnS,33+(i-1)+(r-1)*NnB+(j-1)*NnS,188+(i-1)+(r-1)*NnB+(j-1)*NnS);
                
            end
    end
end
