close all;
clear all;

A=fileread('action_potential.txt');

%Vm_1867=[1,1:80];
B=strfind(A, ' YQS(niqs,    123)');
for i=1:1000
Digit=A(B(i)+19:B(i)+31);
Vm_123(1,i)=str2num(Digit);
end
% 
% Vm_1915=[1,1:80];
% B=strfind(A, ' YQS(niqs,   1915):');
% for i=1:81
% Digit=A(B(i)+19:B(i)+31);
% Vm_1915(1,i)=str2num(Digit);
% end
% 
% 
% Vm_23963=[1,1:80];
% B=strfind(A, ' YQS(niqs,  23963):');
% for i=1:81
% Digit=A(B(i)+19:B(i)+31);
% Vm_23963(1,i)=str2num(Digit);
% end
% 
% Vm_7498=[1,1:80];
% B=strfind(A, ' YQS(niqs,   7498):');
% for i=1:81
% Digit=A(B(i)+19:B(i)+31);
% Vm_7498(1,i)=str2num(Digit);
% end
% 
% 
% Vm_7546=[1,1:80];
% B=strfind(A, ' YQS(niqs,   7546):');
% for i=1:81
% Digit=A(B(i)+19:B(i)+31);
% Vm_7546(1,i)=str2num(Digit);
% end
% 
% Vm_28186=[1,1:80];
% B=strfind(A, ' YQS(niqs,  28186):');
% for i=1:81
% Digit=A(B(i)+19:B(i)+31);
% Vm_28186(1,i)=str2num(Digit);
% end
