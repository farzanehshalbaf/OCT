clear all;
close all;
writerObj = VideoWriter('Bipolar_surface');
writerObj.FrameRate = 2;
writerObj.open;
A=imread('whole.png');
writeVideo(writerObj,A);
B=imread('Picture.png');
B = imresize(B, [1124 1715]);
writeVideo(writerObj,B);
writeVideo(writerObj,B);
writeVideo(writerObj,B);
writeVideo(writerObj,B);
for i=4:4:80
    filename = sprintf('%d.png',i); 
    A=imread(filename);
    writeVideo(writerObj,A);
end
writerObj.close;




