close all;
clear all;
Vm=[1,1:80];
A=fileread('action_potential.txt');
B=strfind(A, 'YQS(niqs,      1):');
for i=1:81
Digit=A(B(i)+19:B(i)+29);
Vm(1,i)=str2num(Digit);
end