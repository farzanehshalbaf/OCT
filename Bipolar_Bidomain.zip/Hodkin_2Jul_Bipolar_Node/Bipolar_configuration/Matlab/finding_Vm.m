close all;
clear all;

A=fileread('action_potential.txt');

Vm_1860=[1,1:80];
B=strfind(A, ' YQS(niqs,   1860):');
for i=1:81
Digit=A(B(i)+19:B(i)+31);
Vm_1860(1,i)=str2num(Digit);
end

Vm_1908=[1,1:80];
B=strfind(A, ' YQS(niqs,   1908):');
for i=1:81
Digit=A(B(i)+19:B(i)+31);
Vm_1908(1,i)=str2num(Digit);
end


Vm_23956=[1,1:80];
B=strfind(A, ' YQS(niqs,  23956):');
for i=1:81
Digit=A(B(i)+19:B(i)+31);
Vm_23956(1,i)=str2num(Digit);
end

Vm_7492=[1,1:80];
B=strfind(A, ' YQS(niqs,   7492):');
for i=1:81
Digit=A(B(i)+19:B(i)+31);
Vm_7492(1,i)=str2num(Digit);
end


Vm_7540=[1,1:80];
B=strfind(A, ' YQS(niqs,   7540):');
for i=1:81
Digit=A(B(i)+19:B(i)+31);
Vm_7540(1,i)=str2num(Digit);
end

Vm_28180=[1,1:80];
B=strfind(A, ' YQS(niqs,  28180):');
for i=1:81
Digit=A(B(i)+19:B(i)+31);
Vm_28180(1,i)=str2num(Digit);
end
