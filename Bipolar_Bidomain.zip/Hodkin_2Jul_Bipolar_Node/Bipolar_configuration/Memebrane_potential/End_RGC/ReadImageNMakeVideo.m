clear all;
close all;
writerObj = VideoWriter('Bipolar_EndRGC');
writerObj.FrameRate = 2;
writerObj.open;
A=imread('whole.png');
A = imresize(A, [1124 1715]);
writeVideo(writerObj,A);
B=imread('Picture.png');
B = imresize(B, [1124 1715]);
writeVideo(writerObj,B);
writeVideo(writerObj,B);
writeVideo(writerObj,B);
writeVideo(writerObj,B);
for i=4:4:80
    filename = sprintf('%d.png',i); 
    A=imread(filename);
    A = imresize(A, [1124 1715]);
    writeVideo(writerObj,A);
end
writerObj.close;




